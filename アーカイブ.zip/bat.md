# [bat](https://github.com/sharkdp/bat)
![image](https://github.com/sharkdp/bat/raw/master/doc/logo-header.svg)
+ シンタックスハイライトと[[Git]]との連携機能が付いた[[cat]]コマンドののクローン。

<- [[CLI]]