# [Obsidian](https://github.com/sharkdp/bat)
![Obsidian](https://obsidian.md/images/screenshot.png)
ローカルで動作するナレッジベース。

## `fas:Download` Install
```shell
$ brew install obsidian --cask 
```

## `rir:Book2` Usage
- ⌨️ [[Obsidian Shortcut Key]]

## `ris:Plug` Plugin
- ⌨️ [[Obsidian Vimrc Support]]
- 😀 [[Icons]]

## `fas:Paperclip` Reference
- [Release Note](https://forum.obsidian.md/c/announcements/13)
- [Obsidian PKM Map](https://www.ankiyorihajimeyo.com/obsidian/links_obsidians/https://www.ankiyorihajimeyo.com/obsidian/links_obsidians/)
- [Obsidian を使いはじめたが、君はどう使う](https://aruhito.net/2020-12-16-i-started-using-obsidian/)
- [Obsidianのここが良い](https://cyblog.jp/41608)