# [Google Drive](https://drive.google.com/drive/)
![image](https://i.imgur.com/i1CT9Aw.png)

+ [[Google]]の[[Cloud Storage]]サービス。 
+ [[PDF]]管理に使用している。

## `fas:FilePdf` 管理ドキュメント
- `fas:Folder` お金
	- `fas:Folder` 給与明細
	- `fas:Folder` 源泉徴収票
	- `fas:Folder` 国民健康保険
	- `fas:Folder` 住民票
- `fas:Folder` 会社
	- `fas:Folder` FIT
	- `fas:Folder` PERSOL
- `fas:Folder` 病院
	- `fas:Folder` 医療費明細書
	- `fas:Folder` 健康診断書
	- `fas:Folder` 処方箋
	- `fas:Folder` 診断書
	- `fas:Folder` 領収書
- `fas:Folder` 個人
	- `fas:Folder` ハローワーク
	- `fas:Folder` 資格
	- `fas:Folder` 身分証明書
	- `fas:Folder` 説明書
	- `fas:Folder` 役所
