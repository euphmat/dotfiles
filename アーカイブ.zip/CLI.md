 # `rir:TerminalBox` CLI

+ 🦇 [[bat]]
+ `fas:Folder` [[exa]]
+ `fas:Search` [[fd]]
+ `fas:Fish` [[fish]]
+ `fas:FileArchive` [[Unar]]
+ `fas:GitAlt` [[Git]]
+ `fas:Youtube` [[Youtube-dl]]
+ `rir:Mac` [[mac-cleanup]]
+ `fas:AppStore` [[mas]]
+ `fas:Beer` [[Homebrew]]