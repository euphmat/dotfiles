# [mac-cleanup](https://github.com/fwartner/mac-cleanuphttps://github.com/fwartner/mac-cleanup)
![image](https://i.imgur.com/96kDGK3.png)

## `fas:Download` Install
```shell
$ brew tap fwartner/tap
$ brew install fwartner/tap/mac-cleanup
```

## `rir:Book2` Usage
```shell
$ mac-clenup [option]
```

## `fas:Cog` Option
|Option|Desc|
|:---|:---|
|`-h`|ヘルプを表示|
|`-v`|デバッグ情報の表示|
|`-u`|[[Homebrew]]本体とパッケージののアップデートを実行|
|`-n`|[[Homebrew]]のアップデートを実行しない|

## `fas:Cogs` Dependency
none