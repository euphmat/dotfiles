# [Google Chrome](https://www.google.com/intl/ja_jp/chrome/)
![image](https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Google_Chrome_75_screenshot.png/650px-Google_Chrome_75_screenshot.png)

## `fas:Cog` Config

## `fas:Keyboard` ShortCut Key
|Key|Desc|
|:---|:---|
|`⌘ Command` + `T`|新規タブを開く|
|`⌘ Command` + `W`|タブを閉じる|
|`⌘ Command` + `F`|検索|
|`⌘ Command` + `R`|リロード|
|`⌘ Command` + `Y`|履歴を開く|
|`⌘ Command` + `G`|検索してフォーカス|
|`⌘ Command` + `⇧ Shift` + `T`|閉じたタブを開く|
|`⌘ Command` + `⇧ Shift` + `B`|ブックマークバーを閉じる|
|`⌘ Command` + `⇧ Shift` + `N`|シークレットモードの起動|


## `fas:Plug` Extensions
- `ris:LockPassword` [[Bitwarden]]
- `fas:Amazon` [[keepa]]
- `fas:GetPocket` [[Pocket]]
- `fas:Search` [[Search Preview]]
- `fas:ShieldAlt` [[uBlock Origin]]
- `fas:VimeoV`️ [[Vimium]]

