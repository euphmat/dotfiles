# `fas:Tools` Tool
## `rir:FileText` Text Editor
+ `rir:FileText` [[Visual Studio Code]]
+ `far:StickyNote` [[Notion]]
+ `fas:VimeoV` [[Vim]]
+ `ris:VipDiamond` [[Obsidian]] ![](https://progress-bar.dev/70/)

## `fas:Music` Music
+ `fas:Spotify` [[Spotify]]
+ `fas:Guitar` [[Garage Band]]
      
## `ris:Rocket2` Lancher
+ `fas:Camera` [[Mapture]]
+ `fas:HatCowboy` [[Alfred]]
+ `fas:Google` [[Google Japanese IME]]
+ `fas:WindowMaximize` [[Rectangle]]
+ `fas:Keyboard` [[Karabiner-Elements]]

## `fas:Cloud` Cloud Storage
+ `ris:Drive` [[Google Drive]]
+ `fas:Dropbox` [[Dropbox]]

## `ris:Todo` Task Manager
+ `ris:Task` [[Things]]

## `ris:Window2` Internet Browser
+ `fas:Chrome` [[Google Chrome]]
+ `fas:Star` [[Reeder]]