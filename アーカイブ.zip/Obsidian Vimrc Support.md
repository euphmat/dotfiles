# 💎 Obsidian Vimrc Support

## URL
[esm7/obsidian-vimrc-Support](https://github.com/esm7/obsidian-vimrc-support)

## Reference
