# 💎 Obsidian Shortcut Key

## ShortCut Key
|Key|Description|
|:-- |:--|
|`⌘ Command` + `Enter`|カーソル下のリンクへ移動|
|`⌘ Command` + `O`|ファイル移動|
|`⌘ Command` + `E`|マークダウン／プレビュー切り替え|
|`⌘ Command` + `G`|グラフビュー表示|
|`⌘ Command` + `Shift` + `T`|テンプレート挿入|
|`⌘ Command` + `Shift` + `N`|新規ファイル作成|