# `fas:LaptopCode` [[Programming]]

- `fas:Python` [[Python]]
- `rir:TerminalBox` [[ShellScript]]